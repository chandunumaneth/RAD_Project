import React, { useEffect, useState } from 'react';
import './List.css';
import axios from "axios";
import { toast } from "react-toastify";

const List = ({ url }) => {
  const [list, setList] = useState([]);

  const fetchList = async () => {
    try {
      const response = await axios.get(`${url}/api/food/list`);
      console.log("Response:", response); // Inspect the entire response object
      if (response.data.success) {
        console.log("List:", response.data.foods); // Inspect the data value
        setList(response.data.foods);
      } else {
        toast.error('Error fetching list');
      }
    } catch (error) {
      console.error("Error fetching list:", error); // Detailed error logging
      toast.error('Error fetching list');
    }
  };

  const removeFood = async (foodId) => {
    try {
      const response = await axios.post(`${url}/api/food/remove`, { id: foodId });
      if (response.data.success) {
        toast.success(response.data.message);
        await fetchList();
      } else {
        toast.error('Error removing food');
      }
    } catch (error) {
      console.error("Error removing food:", error); // Detailed error logging
      toast.error('Error removing food');
    }
  };

  useEffect(() => {
    fetchList();
  }, []);

  return (
    <div className='list add flex-col'>
      <p>All Foods List</p>
      <div className="list-table">
        <div className="list-table-format title">
          <b>Image</b>
          <b>Name</b>
          <b>Category</b>
          <b>Price</b>
          <b>Shop</b> {/* Added header for Shop */}
          <b>Action</b>
        </div>
        {list.map((item, index) => (
          <div key={index} className='list-table-format'>
            <img src={`${url}/images/${item.image}`} alt="" />
            <p>{item.name}</p>
            <p>{item.category}</p>
            <p>${item.price}</p>
            <p>{item.shop ? item.shop.name : 'No Shop'}</p> {/* Displaying store name */}
            <p onClick={() => removeFood(item._id)} className='cursor action-button'>Remove</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default List;
